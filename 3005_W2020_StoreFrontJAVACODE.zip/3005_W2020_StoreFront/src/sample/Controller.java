package sample;

import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

public class Controller {

    @FXML Button BrowseButton;
    @FXML Button CartButton;
    @FXML Button TrackButton;
    @FXML Button AccountButton;
    @FXML Button ReportsButton;
    @FXML ListView bookViewer;
    @FXML Label Title;
    @FXML Label Price;
    @FXML Label Author;
    @FXML Label Pages;
    @FXML ImageView BookCover;

    @FXML Pane window;

    @FXML VBox MenuBar;
    @FXML Group StoreView;
    @FXML Group CartView;



    String selectedBook = null;


    public Controller(){
    }

    @FXML
    public void initialize(){
        window.getChildren().clear();
        window.getChildren().add(StoreView);
    }
    public void onSelect(){
        if (selectedBook!= null && !selectedBook.equals(bookViewer.getSelectionModel().getSelectedItem()))
        {
            System.out.println("rere");
            //new selection, need to update the preview from the DB
            selectedBook = (String)bookViewer.getSelectionModel().getSelectedItem();
            //TEMP:
            this.showPreview();
        } else if (selectedBook== null){
            selectedBook = (String)bookViewer.getSelectionModel().getSelectedItem();
            if (selectedBook != null){
                this.showPreview();
            }
        }
        System.out.println(selectedBook);
    }
    public void showPreview(){
        //call DB with selected title and get back the DB info
        //previewPane.title = asdgasdga
        //....
        if (selectedBook.equals("Harry Potter 1")){
            Title.setText("Harry Potter 1");
            Author.setText("J.K. Rowling");
            Pages.setText("316");
            Price.setText("$19.96");
            BookCover.setImage(new Image("/sample/Resources/image.jpg"));
        }
        if (selectedBook.equals("Harry Potter 2")){
            Title.setText("Harry Potter 2");
            Author.setText("J.K. Rowling");
            Pages.setText("512");
            Price.setText("$19.96");
            BookCover.setImage(new Image("/sample/Resources/hp2.jpeg"));
        }
    }


    public void b1Click(){
        window.getChildren().clear();
        window.getChildren().add(StoreView);
    }

    public void b2Click(){
        window.getChildren().clear();
        window.getChildren().add(CartView);
    }

    //region Button Listeners
    public void b1Hover(){
        if (BrowseButton.isHover()){
            //being hovered, update to hovor color
            BrowseButton.setStyle("-fx-border-color: black; -fx-background-color: #1A53E8; -fx-background-image: url('/sample/resources/BookIcon.png')");
        } else {
            //not being hovered, return to defualt
            BrowseButton.setStyle("-fx-border-color: black; -fx-background-color: #3161E8; -fx-background-image: url('/sample/resources/BookIcon.png')");
        }
    }
    public void b2Hover(){
        if (CartButton.isHover()){
            //being hovered, update to hovor color
            CartButton.setStyle("-fx-border-color: black; -fx-background-color: #1A53E8; -fx-background-image: url('/sample/resources/cartIcon.png')");
        } else {
            //not being hovered, return to defualt
            CartButton.setStyle("-fx-border-color: black; -fx-background-color: #3161E8; -fx-background-image: url('/sample/resources/cartIcon.png')");
        }
    }
    public void b3Hover(){
        if (TrackButton.isHover()){
            //being hovered, update to hovor color
            TrackButton.setStyle("-fx-border-color: black; -fx-background-color: #1A53E8; -fx-background-image: url('/sample/resources/TruckIcon.png')");
        } else {
            //not being hovered, return to defualt
            TrackButton.setStyle("-fx-border-color: black; -fx-background-color: #3161E8; -fx-background-image: url('/sample/resources/TruckIcon.png')");
        }
    }
    public void b4Hover(){
        if (AccountButton.isHover()){
            //being hovered, update to hovor color
            AccountButton.setStyle("-fx-border-color: black; -fx-background-color: #1A53E8; -fx-background-image: url('/sample/resources/accountIcon.png')");
        } else {
            //not being hovered, return to defualt
            AccountButton.setStyle("-fx-border-color: black; -fx-background-color: #3161E8; -fx-background-image: url('/sample/resources/accountIcon.png')");
        }
    }
    public void b5Hover(){
        if (ReportsButton.isHover()){
            //being hovered, update to hovor color
            ReportsButton.setStyle("-fx-border-color: black; -fx-background-color: #1A53E8; -fx-background-image: url('/sample/resources/ChartIcon.png')");
        } else {
            //not being hovered, return to defualt
            ReportsButton.setStyle("-fx-border-color: black; -fx-background-color: #3161E8;  -fx-background-image: url('/sample/resources/ChartIcon.png')");
        }
    }
    //endregion
}
