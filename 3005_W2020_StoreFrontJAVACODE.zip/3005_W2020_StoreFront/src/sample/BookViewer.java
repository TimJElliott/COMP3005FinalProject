package sample;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;

import java.util.*;

public class BookViewer {

    @FXML ListView BookView;
    String selectedTitle = null;


    public BookViewer(){
    }

    @FXML
    public void initialize(){
        //Needs to pull titles and authors maybe? or just last names? from DB
        ObservableList<String> booksTitles = FXCollections.observableArrayList("Harry Potter 1", "Harry Potter 2", "Book3");
        BookView.setItems(booksTitles);
    }


}
